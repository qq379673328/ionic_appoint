angular.module('app.controllers', [])
     
.controller('mainIndexCtrl', function($scope, $state) {
	$scope.toSearch = function(){
		$state.go("searchHosAndDoc");
	};
})
   
   
.controller('mainMedicalrecordCtrl', function($scope, MedicalRecordService) {

	$scope.refreshMedicalRecored = function(idNo){
		MedicalRecordService.getOutpatientRecords(idNo).then(function(data){
			$scope.records = data
		});
	};

	

})
      
.controller('mainNewsCtrl', function($scope) {

})
   
.controller('mainMyCtrl', function($scope) {

})
 
 //登录
.controller('loginCtrl', function($scope, UserService, $cordovaToast) {	
	$scope.loginParams = {username:null, password: null};
	$scope.login = function(){
		UserService.login($scope.loginParams);
	};
})

 //搜索医院和医生
.controller('searchHosAndDocCtrl', function($scope, $stateParams, HospitalService, DoctorService) {
	
	$scope.search = function(){
		HospitalService.getHospitals({keyWord: $scope.searchStr})
		.then(function(data){
			$scope.hospitals = data.hospitalSimples;
		});
		DoctorService.getDoctors({keyWord: $scope.searchStr})
		.then(function(data){
			$scope.doctors = data.doctors;
		});
	};

})

 //消息列表页
.controller('messagesCtrl', function($scope, MessageService) {
	MessageService.getUnreadMessages().then(function(data){
		$scope.messages = data.data.message;
	});
})

 //医院-详情
.controller('hosDetailCtrl', function($scope, hos) {
	$scope.hos = hos;
})
   
.controller('signupCtrl', function($scope) {

})
 